﻿CREATE PROCEDURE CalculateReturnFine
AS
	UPDATE dbo.[Return] 
	SET [Return].ElapsedDate = [Return].ElapsedDate + DATEDIFF(DAYOFYEAR, CONVERT(date, [Return].ReturnDate), CONVERT(date, [Rental].EndDate))
		WHERE DATEDIFF(dayofyear, CONVERT(date, [Return].ReturnDate), CONVERT(date, [Rental].EndDate)) >= 1; 

	UPDATE dbo.[Return] 
	SET Fine = Fine + (ElapsedDate * 500);