﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace TheRideYouRent.Models
{
    //This code was taken from StackOverFlow
    //Posted by: Ali Humayun
    //Available at: https://stackoverflow.com/questions/9720143/asp-net-web-application-message-box
    //Accessed 27 July 2023
    public static class MessageBox
    {
            public static void Show(this Page Page, String Message)
            {
                Page.ClientScript.RegisterStartupScript(
                   Page.GetType(),
                   "MessageBox",
                   "<script language='javascript'>alert('" + Message + "');</script>"
                );
            }
    }
}